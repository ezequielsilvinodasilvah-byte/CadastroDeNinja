package dev.java10x.CadastroDeNinjas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CadastroDeNinjasApplicationTests {

	@Test
	void contextLoads() {
	}

}
